INSERT INTO icd9_folder VALUES(1,'My Favorites');
INSERT INTO icd10_folder VALUES(1,'My Favorites');
