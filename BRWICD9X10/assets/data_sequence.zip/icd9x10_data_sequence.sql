DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('icd9',14567);
INSERT INTO "sqlite_sequence" VALUES('icd10',69823);
INSERT INTO "sqlite_sequence" VALUES('icd9_gem',23936);
INSERT INTO "sqlite_sequence" VALUES('icd10_gem',79066);
INSERT INTO "sqlite_sequence" VALUES('icd9_group',1);
INSERT INTO "sqlite_sequence" VALUES('icd10_group',1);
